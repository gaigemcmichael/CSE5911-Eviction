final class VarSlot {
    final VarKind kind;
    Integer intVal;
    ObjRef objRef;
    VarSlot(VarKind k) {
        this.kind = k;
        this.intVal = (k == VarKind.INT) ? 0 : null;
        this.objRef = null;
    }
}
