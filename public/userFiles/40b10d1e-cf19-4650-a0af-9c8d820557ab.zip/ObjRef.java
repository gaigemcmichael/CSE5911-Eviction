import java.util.*;

final class ObjRef {
    private final Map<String,Integer> map = new HashMap<>();
    private String defaultKey;

    ObjRef(String defaultKey, int initial) {
        this.defaultKey = defaultKey;
        map.put(defaultKey, initial);
    }

    int get(String key) {
        if (!map.containsKey(key)) {
            throw new RuntimeException("Missing key: " + key);
        }
        return map.get(key);
    }

    void put(String key, int val) { map.put(key, val); }

    int getDefault() { return get(defaultKey); }
    void setDefault(int val) { put(defaultKey, val); }
    void setDefaultKey(String k) { this.defaultKey = k; }
}
