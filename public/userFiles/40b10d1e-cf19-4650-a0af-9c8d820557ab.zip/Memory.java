import java.util.*;

final class Memory {
    private final Map<String,VarSlot> globals = new HashMap<>();

    void declareInt(String id) {
        if (globals.containsKey(id)) throw new RuntimeException("Redeclaration of " + id);
        globals.put(id, new VarSlot(VarKind.INT));
    }
    void declareObj(String id) {
        if (globals.containsKey(id)) throw new RuntimeException("Redeclaration of " + id);
        globals.put(id, new VarSlot(VarKind.OBJ));
    }
    VarSlot lookup(String id) {
        VarSlot v = globals.get(id);
        if (v == null) throw new RuntimeException("Undeclared identifier: " + id);
        return v;
    }
}
