import java.nio.file.Path;

class Main {
	public static void main(String[] args) {
		try {
			if (args.length != 2) { System.out.println("Usage: java Main <program.code> <input.data>"); return; }
			CoreScanner S = new CoreScanner(args[0]);
			Parser.scanner = S;
			Procedure p = new Procedure();
			p.parse();
			ExecContext ctx = new ExecContext(new Memory(), new DataSource(Path.of(args[1])), System.out);
			p.execute(ctx);
		} catch (RuntimeException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}
}