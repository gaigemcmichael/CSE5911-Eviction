import java.nio.file.*; import java.io.*; import java.util.*;
final class DataSource {
    private final Iterator<Integer> it;
    DataSource(Path dataPath) {
        try {
            String s = Files.readString(dataPath);
            List<Integer> nums = new ArrayList<>();
            for (String tok : s.trim().split("\s+")) {
                if (!tok.isEmpty()) nums.add(Integer.parseInt(tok));
            }
            this.it = nums.iterator();
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
    int next() {
        if (!it.hasNext()) throw new RuntimeException("read() failed: no more input data");
        return it.next();
    }
}
