Vincent Guevarra


DataSource.java
- It reads a whitespace-separated list of integers from a data file and exposes them via next().

ExecContext.java
- Passed to execute/eval methods to access globals, read input, and print output.

Memory.java
- Declares variables (throws on redeclaration) and returns a VarSlot for lookup (throws if identifier undeclared).

ObjRef.java
- Throws RuntimeException on missing key in get().

VarKind.java
- Enum describing whether a VarSlot holds an INT or an OBJ.

VarSlot.java
- Created with a VarKind; intVal initialized to 0 for INT; objRef initially null for OBJ.

Overall design
- Parser builds AST (Procedure, StmtSeq, DeclSeq, Expr, ...) from a .code file using CoreScanner and Parser.
- Main creates ExecContext and calls Procedure.execute(ctx) to run the program.

Testing performed
- Compiled with javac: javac *.java
- Ran sample tests: java Main Correct/N.code Correct/N.data 