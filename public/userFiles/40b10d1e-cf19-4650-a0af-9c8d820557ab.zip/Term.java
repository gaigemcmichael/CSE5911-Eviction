class Term {
	Factor factor;
	Term term;
	int option;
	
	void parse() {
		factor  = new Factor();
		factor.parse();
		if (Parser.scanner.currentToken() == Core.MULTIPLY) {
			option = 1;
		} else if (Parser.scanner.currentToken() == Core.DIVIDE) {
			option = 2;
		}
		if (option != 0) {
			Parser.scanner.nextToken();
			term = new Term();
			term.parse();
		}						
	}
	
	void print() {
		factor.print();
		if (option == 1) {
			System.out.print("*");
			term.print();
		} else if (option == 2) {
			System.out.print("/");
			term.print();
		}
	}
	int eval(ExecContext ctx) {
		int v = factor.eval(ctx);
		if (option == 1) {
			return v * term.eval(ctx);
		}
		if (option == 2) { 
			int r = term.eval(ctx); 
			if (r == 0) {
				throw new RuntimeException("Division by zero"); 
			}
			return v / r; 
		}
		return v;
	}
}