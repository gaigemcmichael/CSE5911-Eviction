enum VarKind { INT, OBJ } 
