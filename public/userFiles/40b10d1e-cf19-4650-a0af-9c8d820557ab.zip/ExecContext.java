import java.io.PrintStream;

final class ExecContext {
    final Memory mem;
    final DataSource data;
    final PrintStream out;

    ExecContext(Memory mem, DataSource data, PrintStream out) {
        this.mem = mem;
        this.data = data;
        this.out = out;
    }
}
